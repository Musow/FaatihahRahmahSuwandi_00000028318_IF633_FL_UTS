package umn.ac.id.faatihahrahmahsuwandi_00000028318_if633_fl_28318;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText Username;
    private EditText Password;
    private Button BtnLogin;
    private Button BtnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Username = (EditText) findViewById(R.id.usernames);
        Password = (EditText) findViewById(R.id.password);
        BtnLogin = (Button) findViewById(R.id.btnLogin);

        BtnLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                validate(Username.getText().toString(), Password.getText().toString());
            }
        });

        BtnBack = (Button) findViewById(R.id.btnBack);
        BtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });


    }

    private void validate(String inputUser, String inputPassword)  {
        if((inputUser.equals("uasmobile")) && (inputPassword.equals("uasmobilegenap"))) {
            Intent intent = new Intent(this, umn.ac.id.faatihahrahmahsuwandi_00000028318_if633_fl_28318.MusicActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(umn.ac.id.faatihahrahmahsuwandi_00000028318_if633_fl_28318.LoginActivity.this, "Email or Password is wrong", Toast.LENGTH_LONG).show();
        }
    }

    private void back() {
        Intent intent = new Intent(this, umn.ac.id.faatihahrahmahsuwandi_00000028318_if633_fl_28318.MainActivity.class);
        startActivity(intent);
    }

}