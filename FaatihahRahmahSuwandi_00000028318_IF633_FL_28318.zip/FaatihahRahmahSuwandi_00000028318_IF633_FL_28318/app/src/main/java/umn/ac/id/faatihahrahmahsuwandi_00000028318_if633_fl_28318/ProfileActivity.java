package umn.ac.id.faatihahrahmahsuwandi_00000028318_if633_fl_28318;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {
    private Button BtnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        BtnBack = (Button) findViewById(R.id.btnBack);
        BtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
    }

    private void back() {
        Intent intent = new Intent(this, umn.ac.id.faatihahrahmahsuwandi_00000028318_if633_fl_28318.MainActivity.class);
        startActivity(intent);
    }
}